<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php if(trim($slot) === 'SUDTECH'): ?>

SUD<span class="text-red-500">TE</span>CH
<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH E:\Projects\Inertia-exam\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>